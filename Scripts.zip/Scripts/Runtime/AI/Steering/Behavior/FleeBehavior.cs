using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class FleeBehavior : SteeringBehavior
    {
        public FleeBehavior(ShipDynamics s) : base(s)
        {
        }
        public override Vector2 GetShipInput(Vector3 currentPosition, 
            Vector3 currentVelocity, 
            Vector3 targetPosition, 
            Vector3 targetVelocity, 
            float speed)
        {
            Vector3 desiredDirection = (currentPosition - targetPosition).normalized;
            return shipInput;
        }
    }
}
