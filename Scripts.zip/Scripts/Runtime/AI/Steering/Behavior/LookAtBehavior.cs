using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class LookAtBehavior : SteeringBehavior
    {
        public LookAtBehavior(ShipDynamics s) : base(s)
        {
        }
        public override Vector2 GetShipInput(Vector3 currentPosition, 
            Vector3 currentVelocity, 
            Vector3 targetPosition, 
            Vector3 targetVelocity, 
            float speed)
        {
            ShipProperties shipProperties = ship.gameObject.GetComponent<ShipProperties>();

            Vector3 firePosition = CalculateTargetPosition(currentPosition, currentVelocity, targetPosition, shipProperties.aiFireRadius);

            

            Vector3 moveDirection = (firePosition - currentPosition).normalized;

            if (Vector3.Dot(moveDirection, currentVelocity) >= 0) //in front
            {
                shipInput.x = 1;
            }
            //else
            //{
            //    shipInput.x = -1;
            //}

            Vector3 right = Vector3.Cross(currentVelocity.normalized, Vector3.up);
            if (Vector3.Dot(moveDirection, right) >= 0) //right side
            {
                shipInput.y = -1;
            }
            else
            {
                shipInput.y = 1;
            }

            return shipInput;
        }

        Vector3 CalculateTargetPosition(Vector3 point, Vector3 velocity, Vector3 center, float radius)
        {
            Vector3 distance3d = point - center;
            distance3d.y = 0;

            float distance = distance3d.magnitude;

            if (distance <= radius)
            {
                return point;
            }

            float cosTheta = radius / distance;
            float sinTheta = Mathf.Sqrt(distance * distance - radius * radius) / distance;

            Vector3 direction = distance3d.normalized;
            Vector3 positionA = center + RotateVectorClockwise(direction, cosTheta, sinTheta) * radius;
            Vector3 positionB = center + RotateVectorCounterClockwise(direction, cosTheta, sinTheta) * radius;

            if (Vector3.Dot((positionA - point).normalized, velocity) > Vector3.Dot((positionB - point).normalized, velocity))
            {
                return positionA;
            }
            else
            {
                return positionB;
            }
        }

        Vector3 RotateVectorClockwise(Vector3 vector, float cosTheta, float sinTheta)
        {
            float x = vector.x * cosTheta + vector.z * sinTheta;
            float z = -vector.x * sinTheta + vector.z * cosTheta;

            return new Vector3(x, vector.y, z);
        }

        Vector3 RotateVectorCounterClockwise(Vector3 vector, float cosTheta, float sinTheta)
        {
            float x = vector.x * cosTheta - vector.z * sinTheta;
            float z = vector.x * sinTheta + vector.z * cosTheta;

            return new Vector3(x, vector.y, z);
        }
    }
}
