using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class SeekBehavior : SteeringBehavior
    {
        public SeekBehavior(ShipDynamics s) : base(s)
        {
        }
        public override Vector2 GetShipInput(Vector3 currentPosition, 
            Vector3 currentVelocity, 
            Vector3 targetPosition,
            Vector3 targetVelocity, 
            float speed)
        {
            Vector3 desiredDirection = (targetPosition - currentPosition).normalized;

            

            if (Vector3.Dot(desiredDirection, currentVelocity) >= 0) //in front
            {
                shipInput.x = 1;
            }
            else
            {
                shipInput.x = 0;
            }

            Vector3 right = Vector3.Cross(currentVelocity.normalized, Vector3.up);
            if (Vector3.Dot(desiredDirection, right) >= 0) //right side
            {
                shipInput.y = -1;
            }
            else
            {
                shipInput.y = 1;
            }

            return shipInput;
        }
    }
}
