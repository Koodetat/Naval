using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public abstract class SteeringBehavior
    {
        protected ShipDynamics ship;

        protected Vector2 shipInput = Vector2.zero;

        public SteeringBehavior(ShipDynamics s)
        {
            ship = s;
        }
        public abstract Vector2 GetShipInput(Vector3 currentPosition, 
            Vector3 currentVelocity, 
            Vector3 targetPosition,
            Vector3 targetVelocity,
            float speed);
    }
}
