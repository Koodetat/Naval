using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public enum SteeringType
    {
        ST_SEEK,
        ST_LOOKAT,
        ST_FLEE,

        ST_COUNT,
    }

    public class SteeringController : MonoBehaviour
    {
        public Transform target;
        public float speed = 5f; // move speed

        public ShipDynamics ship;

        private SteeringBehavior[] behaviors;
        private List<float> steeringPattern = new List<float>();

        void Awake()
        {
            // Initialise Steering Behaviors
            behaviors = new SteeringBehavior[]
            {
                new SeekBehavior(ship),
                new LookAtBehavior(ship),
                new FleeBehavior(ship)
            };

            for (int i = 0; i < behaviors.Length; i++) 
            { 
                steeringPattern.Add(0); 
            }
        }

        void Update()
        {
            //if (target != null)
            //{
            //    Vector2 steeringInput = Vector3.zero;

            //    // add force and torque
            //    foreach (var behavior in behaviors)
            //    {
            //        steeringInput += behavior.GetShipInput(transform.position, ship.GetVelocoty(), target.position, speed);
            //    }

            //    // move
            //    ship.SetImpetus(steeringInput.x, steeringInput.y);
            //}
        }

        public void SetPatternClose()
        {
            steeringPattern[(int)SteeringType.ST_SEEK] = 1.0f;
            steeringPattern[(int)SteeringType.ST_LOOKAT] = 0;
            steeringPattern[(int)SteeringType.ST_FLEE] = 0;
        }

        public void SetPatternLookAt()
        {
            steeringPattern[(int)SteeringType.ST_SEEK] = 0;
            steeringPattern[(int)SteeringType.ST_LOOKAT] = 1.0f;
            steeringPattern[(int)SteeringType.ST_FLEE] = 0;
        }

        public void SteeringToTarget()
        {
            if (target != null)
            {
                Vector2 steeringInput = Vector3.zero;

                // add force and torque
                for (int i = 0; i < behaviors.Length; i++)
                {
                    SteeringBehavior behavior = behaviors[i];
                    float weight = steeringPattern[i];

                    if (weight < 0.01f) continue;

                    steeringInput += behavior.GetShipInput(transform.position, 
                        ship.GetFrontDir(), 
                        target.position,
                        target.forward,
                        speed) * weight;
                }

                // move
                ship.SetImpetus(steeringInput.x, steeringInput.y);
            }
        }
    }
}
