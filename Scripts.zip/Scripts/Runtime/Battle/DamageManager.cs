using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class CannonballHitShipMessage
    {
        public Cannonball ball;
        public ShipProperties ship;
    }

    public class ShipDeadMessage
    {
        public ShipProperties ship;
    }

    public class OnShipHealthChangeMessage
    {
        public ShipProperties ship;
    }

    public class DamageManager : SingletonMono<DamageManager>
    {
        override protected void Awake()
        {
            base.Awake();

            EventBetter.Listen<DamageManager, CannonballHitShipMessage>(this, OnCannonballHitShip);
        }

        void OnCannonballHitShip(CannonballHitShipMessage msg)
        {
            msg.ship.health -= 50;
            EventBetter.Raise(new OnShipHealthChangeMessage() { ship = msg.ship });

            if (msg.ship.health <= 0)
            {
                Debug.Log("health < 50");
                EventBetter.Raise(new ShipDeadMessage() { ship = msg.ship });
            }
        }
    }
}
