using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using static UnityEngine.GraphicsBuffer;

namespace NavalBattleKit
{
    public class CameraController : SingletonMono<CameraController>
    {
        public float rotateSpeed = 1.0f;
        public float lookDistance = 20;
        public float lookRotateX = 20;

        Vector3 offset;
        Camera renderCamera;
        GameObject target;

        void Start()
        {
            Quaternion rot = Quaternion.Euler(lookRotateX, 0, 0);
            offset = rot * Vector3.forward * lookDistance;

            renderCamera = Camera.main;
            renderCamera.transform.SetParent(transform, false);
            renderCamera.transform.localPosition = Vector3.zero;
            renderCamera.transform.localRotation = Quaternion.identity;

            if (Player.Instance != null)
            {
                target = Player.Instance.CameraTarget.gameObject;
            }
        }

        void LateUpdate()
        {
            if (!InputManager.Instance.Aiming)
            {
                UpdateLookDistance();
                UpdateVerticleOffset();
                UpdateHorizonRotate();
            }

            float desiredAngle = target.transform.eulerAngles.y;
            Quaternion rotation = Quaternion.Euler(0, desiredAngle, 0);
            transform.position = target.transform.position - (rotation * offset);

            transform.LookAt(target.transform);
        }

        void UpdateLookDistance()
        {
            lookDistance += Input.mouseScrollDelta.y * rotateSpeed;
        }

        void UpdateVerticleOffset()
        {
            float verticalDelta = -InputManager.Instance.inputLook.y/*Input.GetAxis("Mouse Y")*/ * rotateSpeed;
            lookRotateX += verticalDelta;
            lookRotateX = Mathf.Clamp(lookRotateX, 0, 80);
            Quaternion rot = Quaternion.Euler(lookRotateX, 0, 0);
            offset = rot * Vector3.forward * lookDistance;
        }

        void UpdateHorizonRotate()
        {
            float horizontal = InputManager.Instance.inputLook.x/*Input.GetAxis("Mouse X")*/ * rotateSpeed;
            target.transform.Rotate(0, horizontal, 0);
        }
    }
}