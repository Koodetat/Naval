namespace CleverCrow.Fluid.BTs.Trees.Editors {
    public interface IGraphContainer : IGraphBox {
        void AddBox (IGraphBox container);
    }
}