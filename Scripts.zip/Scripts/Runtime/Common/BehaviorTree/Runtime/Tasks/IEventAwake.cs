﻿namespace CleverCrow.Fluid.BTs.Tasks {
    public interface IEventAwake {
        void Awake ();
    }
}