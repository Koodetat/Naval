﻿namespace CleverCrow.Fluid.BTs.Tasks {
    public enum TaskStatus {
        Success,
        Failure,
        Continue
    }
}
