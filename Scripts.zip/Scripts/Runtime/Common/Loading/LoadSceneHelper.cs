using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public static class LoadSceneHelper
    {
        public static string loadingScene;
    }
}

