using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace NavalBattleKit
{
    public class LoadSceneUtil : MonoBehaviour
    {
        //public string SceneName;
        // Start is called before the first frame update
        //public void LoadScene()
        //{
        //    LoadSceneHelper.loadingScene = SceneName;
        //    SceneManager.LoadScene("Loading");
        //}

        public void LoadScene(string sceneName)
        {
            LoadSceneHelper.loadingScene = sceneName;
            SceneManager.LoadScene("Loading");
        }
    }
}

