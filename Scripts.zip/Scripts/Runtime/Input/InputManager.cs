using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace NavalBattleKit
{
    public class InputManager : SingletonMono<InputManager>
    {
        public bool Aiming { get; set; }

        //input
#if ENABLE_INPUT_SYSTEM
        public PlayerInput playerInput;
#endif
        public Vector2 inputMove = Vector2.zero;
        public Vector2 inputLook = Vector2.zero;
        public bool inputFire = false;
        public bool inputAim = false;

        //mobile
        public GameObject virtualInputPrefab = null;
        public bool debugShowVirtualInput = false;
        private GameObject virtualInputInstance = null;

        // Start is called before the first frame update
        void Start()
        {
            if (Application.platform == RuntimePlatform.Android || 
                Application.platform == RuntimePlatform.IPhonePlayer ||
                debugShowVirtualInput)
            {
#if ENABLE_INPUT_SYSTEM
                if (playerInput != null)
                {
                    playerInput.neverAutoSwitchControlSchemes = true;
                    playerInput.enabled = false;
                }
#endif

                InitMobileController();
            }
            else
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
        }

        void InitMobileController()
        {
            virtualInputInstance = Instantiate(virtualInputPrefab, transform);
        }

        // Update is called once per frame 
        void Update()
        {
        
        }


        //INPUT MESSAGES
#if ENABLE_INPUT_SYSTEM
        public void OnMove(InputAction.CallbackContext value)
        {
            MoveInput(value.ReadValue<Vector2>());
        }

        public void OnLook(InputAction.CallbackContext value)
        {
            LookInput(value.ReadValue<Vector2>());
        }

        public void OnFire(InputAction.CallbackContext value)
        {
            FireInput(value.performed);
        }

        public void OnAim(InputAction.CallbackContext value)
        {
            AimInput(value.performed);
        }

#endif


        public void MoveInput(Vector2 newMoveDirection)
        {
            inputMove = newMoveDirection;
        }

        public void LookInput(Vector2 newLook)
        {
            inputLook = newLook;
        }

        public void FireInput(bool newFireState)
        {
            inputFire = newFireState;
        }

        public void AimInput(bool newAimState)
        {
            inputAim = newAimState;
        }
    }
}
