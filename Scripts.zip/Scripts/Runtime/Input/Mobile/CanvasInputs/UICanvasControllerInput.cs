using UnityEngine;

namespace NavalBattleKit
{
    public class UICanvasControllerInput : MonoBehaviour
    {

        public void VirtualMoveInput(Vector2 virtualMoveDirection)
        {
            InputManager.Instance.MoveInput(virtualMoveDirection);
        }

        public void VirtualLookInput(Vector2 virtualLookDirection)
        {
            virtualLookDirection.y *= -1;
            InputManager.Instance.LookInput(virtualLookDirection);
        }

        public void VirtualFireInput(bool virtualFireState)
        {
            InputManager.Instance.FireInput(virtualFireState);
        }

        public void VirtualAimInput(bool virtualAimState)
        {
            InputManager.Instance.AimInput(virtualAimState);
        }

    }

}
