﻿using UnityEngine;

namespace NavalBattleKit
{
    public class ShipDynamics : MonoBehaviour
    {
        [SerializeField] private float maxImpetus = 1000f;
        [SerializeField] private float turningFactor = 10000.0f;
        [SerializeField] private float backwardSpeedFactor = 0.5f;

        //public Transform motor;

        private float verticalImpetus = 0f;
        private float horizontalImpetus = 0f;
        private Rigidbody rigidbodyComponent;

        private float acceleration = 0f;
        private float accelerationBreak;

        public float FinalSpeed { set { maxImpetus = value; } get { return maxImpetus; } }

        void Start()
        {
            rigidbodyComponent = GetComponent<Rigidbody>();

            accelerationBreak = maxImpetus * backwardSpeedFactor;
        }

        public void SetImpetus(float verticalImpetus, float horizontalImpetus)
        {
            this.verticalImpetus = Mathf.Clamp(verticalImpetus, -1, 1);
            this.horizontalImpetus = Mathf.Clamp(horizontalImpetus, -1, 1);
        }

        public Vector3 GetFrontDir()
        {
            return transform.forward;
        }

        void FixedUpdate()
        {
            acceleration = 0;
            if (verticalImpetus > 0)
            {
                acceleration = maxImpetus * verticalImpetus;
            }
            else if (verticalImpetus < 0)
            {
                acceleration = maxImpetus * verticalImpetus * backwardSpeedFactor;
            }
            

            rigidbodyComponent.AddRelativeForce(Vector3.forward * acceleration);
            rigidbodyComponent.AddRelativeTorque(0, horizontalImpetus * turningFactor, 0);


            //for stability
            float angle = transform.rotation.eulerAngles.z;
            if (angle >= 180) angle = angle - 360;
            //Debug.Log("stable angle = " + angle.ToString());
            rigidbodyComponent.AddRelativeTorque(0, 0, -1000 * angle);
        }
    }
}