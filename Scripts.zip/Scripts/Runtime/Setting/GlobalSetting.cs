using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class GlobalSetting
    {
        public static Vector3 gravity = new Vector3(0, -9.8f, 0);
        public static float animMouseSensitivity = 30;
    }
} 