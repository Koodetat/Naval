using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using CleverCrow.Fluid.BTs.Trees;
using CleverCrow.Fluid.BTs.Tasks;
using CleverCrow.Fluid.BTs.Decorators;

namespace NavalBattleKit
{
    public class Enemy : MonoBehaviour
    {
        [SerializeField]
        private BehaviorTree behaviorTree;

        public ShipDynamics player;

        public GameObject healthBarObject;

        private ShipController shipController;
        private SteeringController steeringController;
        private ShipProperties shipProperties;

        void Start()
        {
            steeringController = GetComponent<SteeringController>();
            shipController = GetComponent<ShipController>();
            shipProperties = GetComponent<ShipProperties>();

            EventBetter.Listen<Enemy, ShipDeadMessage>(this, OnShipDead);

            behaviorTree = new BehaviorTreeBuilder(gameObject)
                .Selector()
                    .Sequence("Try Fire")
                        .Condition("Find Player", () => { return player != null; })
                        .Condition("Check Can Fire", () => { return CanFire(); })
                        .Do("Fire", () => {

                            Fire();

                            return TaskStatus.Success;
                        })
                    .End()
                    .Sequence("Move To Player")
                        .Condition("Find Player", () => { return player != null; })
                        .Do("Close To Player", () => {

                            Vector3 distance3D = transform.position - player.transform.position;
                            float distance = distance3D.magnitude;
                            if (distance < shipProperties.aiPrepareFireRadius)
                            {
                                return TaskStatus.Success;
                            }

                            steeringController.SetPatternClose();
                            steeringController.SteeringToTarget();

                            return TaskStatus.Failure;
                        })
                        .Do("Prepare To Fire", () => {

                            steeringController.SetPatternLookAt();
                            steeringController.SteeringToTarget();

                            return TaskStatus.Success;
                        })
                    .End()
                .Build();
        }

        // Update is called once per frame
        void Update()
        {
            if (shipProperties.IsDead()) return;

            behaviorTree.Tick();
        }

        bool CanFire()
        {
            Vector3 distance3D = transform.position - player.transform.position;
            float distance = distance3D.magnitude;
            if (distance > shipProperties.aiFireRadius + 5)
            {
                return false;
            }

            ShipSide side = CalculateFireSide();
            return shipController.CheckFireFaceGameObject(side, player.gameObject);
        }

        void Fire()
        {
            ShipSide side = CalculateFireSide();
            int maxStep = 20;
            float initAngle = -3;
            Vector3 aimDir = shipController.SetAim(side, initAngle);
            while (maxStep > 0)
            {
                if (aimDir.y > 0.2)
                {
                    initAngle += 5;
                    maxStep--;
                    aimDir = shipController.SetAim(side, initAngle);
                    continue;
                }
                else if (aimDir.y < -0.2)
                {
                    initAngle -= 5;
                    maxStep--;
                    aimDir = shipController.SetAim(side, initAngle);
                    continue;
                }

                break;
            }
            
            shipController.FireGroup(side);
        }

        ShipSide CalculateFireSide() 
        { 
            Vector3 distance3D = player.transform.position - transform.position;
            Vector3 distanceHorizon = distance3D;
            distanceHorizon.y = 0;

            Vector3 shipRight = transform.right;
            Vector3 shipRightHorizon = shipRight;
            shipRightHorizon.y = 0;

            float cos = Vector3.Dot(distanceHorizon.normalized, shipRightHorizon.normalized);

            ShipSide side = cos > 0 ? ShipSide.Right : ShipSide.Left;
            return side;
        }

        void OnShipDead(ShipDeadMessage msg)
        {
            if (shipProperties != msg.ship) return;

            Debug.Log("Ship has been destroyed");
            if (msg.ship != null)
            {
                Rigidbody rd = msg.ship.GetComponent<Rigidbody>();
                if (rd != null)
                {
                    rd.mass = 1000;
                }
            }

            if (healthBarObject != null)
            {
                healthBarObject.SetActive(false);
            }
        }
    }
}
