using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class Mast : MonoBehaviour
    {
        [Range(0, 1)]
        public float rotation = 0.5f;

        [Range(-90, 90)]
        public float rotationMin = -45;
        [Range(-90, 90)]
        public float rotationMax = 45;

        public Sail[] sails = null;

        // Start is called before the first frame update
        void Start()
        {
            for (int i = 0; i < sails.Length; i++)
            {
                if (sails[i] != null)
                {
                    sails[i].mast = this;
                }
            }
        }

        // Update is called once per frame
        void Update()
        {
            Vector3 euler = transform.localEulerAngles;
            euler.y = Mathf.Lerp(rotationMin, rotationMax, rotation);
            transform.localEulerAngles = euler;
        }
    }
}
