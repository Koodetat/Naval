using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class Player : SingletonMono<Player>
    {
        public Transform CameraTarget { get { return cameraTarget; } }
        [SerializeField] private Transform cameraTarget;

        private ShipController shipController;
        private ShipProperties shipProperties;

        protected override void Awake()
        {
            base.Awake();

            shipController = GetComponent<ShipController>();
            shipProperties = GetComponent<ShipProperties>();

            EventBetter.Listen<Player, ShipDeadMessage>(this, OnShipDead);
        }

        // Update is called once per frame
        void Update()
        {
            if (shipProperties.IsDead()) return;

            shipController.SetShipImpetus(InputManager.Instance.inputMove.y, InputManager.Instance.inputMove.x);

            Vector3 lookDir = CameraController.Instance.transform.forward;
            Vector3 shipRight = transform.right;

            Vector3 lookHorizon = lookDir;
            lookHorizon.y = 0;

            Vector3 shipRightHorizon = shipRight;
            shipRightHorizon.y = 0;

            float cos = Vector3.Dot(lookHorizon.normalized, shipRightHorizon.normalized);

            ShipSide side = cos > 0 ? ShipSide.Right : ShipSide.Left;

            if (InputManager.Instance.inputFire)
            {
                shipController.FireGroup(side);
            }

            if (shipController.HasCannonGroup())
            {
                if (!InputManager.Instance.inputAim)
                {
                    shipController.TryShowTrajectory(ShipSide.All, false);
                    InputManager.Instance.Aiming = false;
                }

                if (InputManager.Instance.inputAim)
                {
                    shipController.TryShowTrajectory(side, true);
                    InputManager.Instance.Aiming = true;
                }

                if (InputManager.Instance.Aiming && shipController.GetShowTrajectory(side))
                {
                    shipController.UpdateAim(side, InputManager.Instance.inputLook.y/*Input.GetAxis("Mouse Y")*/ * 0.1f * Time.deltaTime);
                }
            }
        }

        void OnShipDead(ShipDeadMessage msg)
        {
            if (shipProperties != msg.ship) return;

            Debug.Log("Player Ship has been destroyed");
            if (msg.ship != null)
            {
                Rigidbody rd = msg.ship.GetComponent<Rigidbody>();
                if (rd != null)
                {
                    rd.mass = 1000;
                }
            }
        }

    }
}
