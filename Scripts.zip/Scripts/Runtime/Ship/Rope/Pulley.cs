using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{ 
    public class Pulley : MonoBehaviour
    {
        public Transform LeftAnchor;
        public Transform RightAnchor;

        public Transform LeftAttachObject;
        public Transform RightAttachObject;
        // Start is called before the first frame update
        void Start()
        {
        
        }

        // Update is called once per frame
        void Update()
        {
            if (LeftAnchor != null && LeftAttachObject != null)
            {
                LeftAttachObject.position = LeftAnchor.position;
            }

            if (RightAnchor != null && RightAttachObject != null)
            {
                RightAttachObject.position = RightAnchor.position;
            }
        }
    }
}