﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Referenced https://github.com/NoxWings/Cable-Component, made improvements to rendering, and now supports the use of custom models.
//The model needs to have the read-write option enabled.

namespace NavalBattleKit
{
    [RequireComponent(typeof(MeshFilter))]
    //[ExecuteAlways]
    //Currently, there are specific requirements for the production specifications of the rope model.
    public class Rope : MonoBehaviour
    {
        [Header("Phsyics")]
        [SerializeField] private Transform _StartPoint;
        public Transform StartPoint { get { return _StartPoint; } }

        [SerializeField] private Transform _EndPoint;
        public Transform EndPoint { get { return _EndPoint; } }

        [SerializeField] private float _RopeLength = 2f;
        [SerializeField, HideInInspector] private int _TotalSegments = 16;
        [SerializeField, HideInInspector] private int _VerletIterations = 1;
        [SerializeField, HideInInspector] private int _SolverIterations = 1;
        [Range(0.1f, 1f)]
        [SerializeField, HideInInspector] private float _Flexiblity = 1f;
        private RopePhysicsParticle[] _Points;
        private int _Segments = 0;

        [Header("Renderer")]
        private int _RopeBoneCount = 10;
        private Transform[] _RopeBones;

        #region MONOBEHAVIOUR

        void Start()
        {
            InitializePhsyic();
            InitializeRenderer();
        }

        void Update()
        {
            UpdateRopeBones();
        }

        void FixedUpdate()
        {
            for (int verletIdx = 0; verletIdx < _VerletIterations; verletIdx++)
            {
                VerletIntegrate();
                SolveConstraints();
            }
        }

        #endregion

        #region PHYSICS

        void InitializePhsyic()
        {
            // Calculate segments to use
            _Segments = _TotalSegments;

            Vector3 ropeDirection = (_EndPoint.position - transform.position).normalized;
            float initLength = Vector3.Magnitude(_EndPoint.transform.position - _StartPoint.transform.position);
            float initialSegmentLength = initLength / _Segments;
            _Points = new RopePhysicsParticle[_Segments + 1];

            // Foreach point
            for (int pointIdx = 0; pointIdx <= _Segments; pointIdx++)
            {
                // Initial position
                Vector3 initialPosition = transform.position + (ropeDirection * (initialSegmentLength * pointIdx));
                _Points[pointIdx] = new RopePhysicsParticle(initialPosition);
            }
            // Bind start and end particles with their respective gameobjects
            RopePhysicsParticle start = _Points[0];
            RopePhysicsParticle end = _Points[_Segments];
            start.Bind(_StartPoint.transform);
            end.Bind(_EndPoint.transform);
        }

        void VerletIntegrate()
        {
            Vector3 gravityDisplacement = Time.fixedDeltaTime * Time.fixedDeltaTime * Physics.gravity;
            foreach (RopePhysicsParticle particle in _Points)
            {
                particle.UpdateVerlet(gravityDisplacement);
            }
        }

        void SolveConstraints()
        {
            for (int iterationIdx = 0; iterationIdx < _SolverIterations; iterationIdx++)
            {
                SolveDistanceConstraint();
            }
        }

        void SolveDistanceConstraint()
        {
            float segmentLength = _RopeLength / _Segments;
            for (int SegIdx = 0; SegIdx < _Segments; SegIdx++)
            {
                RopePhysicsParticle particleA = _Points[SegIdx];
                RopePhysicsParticle particleB = _Points[SegIdx + 1];

                // Solve for this pair of particles
                // Find current vector between particles
                Vector3 delta = particleB.Position - particleA.Position;
                // 
                float currentDistance = delta.magnitude * (1 / Mathf.Clamp(_Flexiblity, 0.1f, 1f));
                float errorFactor = (currentDistance - segmentLength) / currentDistance;

                // Only move free particles to satisfy constraints
                if (particleA.IsFree() && particleB.IsFree())
                {
                    particleA.Position += errorFactor * 0.5f * delta;
                    particleB.Position -= errorFactor * 0.5f * delta;
                }
                else if (particleA.IsFree())
                {
                    particleA.Position += errorFactor * delta;
                }
                else if (particleB.IsFree())
                {
                    particleB.Position -= errorFactor * delta;
                }
            }
        }

        #endregion

        #region RENDERER

        void InitializeRenderer()
        {
            _RopeBoneCount = _TotalSegments + 1;
            GenerateSkin();
        }

        void UpdateRopeBones()
        {
            for (int pointIdx = 0; pointIdx < _Segments + 1; pointIdx++)
            {
                SetBonePosition(pointIdx, _Points[pointIdx].Position);
            }

            UpdateBoneRotations();
        }

        public Vector3 GetRopePosition(float p)
        {
            float pValue = Mathf.Clamp01(p);

            if (_Segments < 1) return Vector3.zero;

            float indexValue = _Segments * pValue;
            
            int startValue = Mathf.FloorToInt(indexValue);
            int endValue = Mathf.CeilToInt(indexValue);

            return Vector3.Lerp(_Points[startValue].Position, _Points[endValue].Position, indexValue - startValue);
        }

        public void RemoveSkin()
        {
            SkinnedMeshRenderer skinMesh = GetComponent<SkinnedMeshRenderer>();

            if (skinMesh != null)
            {
                Material[] materials = skinMesh.sharedMaterials;
                DestroyImmediate(skinMesh);
                MeshRenderer mesh = gameObject.AddComponent<MeshRenderer>();
                mesh.sharedMaterials = materials;
            }
        }

        //todo, generate once
        public void GenerateSkin()
        {
            MeshFilter meshFilter = GetComponent<MeshFilter>();

            SkinnedMeshRenderer skinMesh = GetComponent<SkinnedMeshRenderer>();

            if (skinMesh != null)
            {
                RemoveSkin();
                skinMesh = null;
            }

            Material[] materials = null;
            if (skinMesh == null)
            {
                MeshRenderer mesh = GetComponent<MeshRenderer>();
                materials = mesh.sharedMaterials;

                skinMesh = gameObject.AddComponent<SkinnedMeshRenderer>();

                if (mesh)
                    DestroyImmediate(mesh);
            }

            Mesh sourceMesh = meshFilter.sharedMesh;
            Vector3[] verts = sourceMesh.vertices;

            //float min = verts[0].x;
            //float max = verts[0].x;
            float min = verts[0].z;
            float max = verts[0].z;
            for (int i = 0; i < verts.Length; i++)
            {
                Vector3 pos = verts[i];
                //if (pos.x < min) min = pos.x;
                //if (pos.x > max) max = pos.x;
                if (pos.z < min) min = pos.z;
                if (pos.z > max) max = pos.z;
            }

            float range = max - min;
            ReGenerateBones(range);

            BoneWeight[] weights = new BoneWeight[sourceMesh.vertexCount];

            for (int i = 0; i < verts.Length; i++)
            {
                Vector3 pos = verts[i];

                float segmentLength = range / (_RopeBoneCount - 1);

                //int index = Mathf.FloorToInt(pos.x / segmentLength);
                int index = Mathf.FloorToInt((pos.z - min) / segmentLength);
                int index0 = Mathf.Clamp(index, 0, _RopeBoneCount - 1);
                int index1 = Mathf.Clamp(index + 1, 0, _RopeBoneCount - 1);
                //float weight = (pos.x % segmentLength) / segmentLength;
                float weight = ((pos.z - min) % segmentLength) / segmentLength;

                if (weight == 0)
                {
                    weights[i].boneIndex0 = index0;
                    weights[i].boneIndex1 = 0;

                    weights[i].weight0 = 1;
                    weights[i].weight1 = 0;
                }
                else
                {
                    weights[i].boneIndex0 = index0;
                    weights[i].boneIndex1 = index1;

                    weights[i].weight0 = 1 - Mathf.Clamp01(weight);
                    weights[i].weight1 = 1.0f - weights[i].weight0;
                }
            }

            sourceMesh.boneWeights = weights;

            Transform[] bones = new Transform[_RopeBoneCount];
            Matrix4x4[] poses = new Matrix4x4[_RopeBoneCount];

            for (int i = 0; i < _RopeBoneCount; i++)
            {
                bones[i] = _RopeBones[i];
                poses[i] = _RopeBones[i].worldToLocalMatrix * transform.localToWorldMatrix;
            }

            sourceMesh.bindposes = poses;
            skinMesh.bones = bones;
            skinMesh.updateWhenOffscreen = true;
            skinMesh.materials = materials;
        }

        public void ReGenerateBones(float meshLength)
        {
            if (_RopeBones != null && _RopeBones.Length > 0)
            {
                for (int i = 0; i < _RopeBones.Length; i++)
                {
                    if (_RopeBones[i] != null)
                    {
                        DestroyImmediate(_RopeBones[i].gameObject);
                    }
                }
            }

            List<Transform> children = new List<Transform>(GetComponentsInChildren<Transform>());

            for (int i = children.Count - 1; i >= 0; i--)
            {
                if (children[i].gameObject != gameObject &&
                    children[i].gameObject != _StartPoint.gameObject &&
                    children[i].gameObject != _EndPoint.gameObject)
                {
                    Destroy(children[i].gameObject);
                }
            }

            _RopeBones = new Transform[_RopeBoneCount];
            for (int i = 0; i < _RopeBoneCount; i++)
            {
                GameObject gameObject = new GameObject("Rope Bone " + i.ToString());
                gameObject.hideFlags = HideFlags.HideAndDontSave;
                _RopeBones[i] = gameObject.transform;
                gameObject.transform.parent = transform;
                //gameObject.transform.localRotation = Quaternion.Euler(0, 90, 0);
                //gameObject.transform.localPosition = new Vector3((meshLength / (_RopeBoneCount - 1)) * i, 0, 0);
                gameObject.transform.localRotation = Quaternion.Euler(0, 0, 0);
                gameObject.transform.localPosition = new Vector3(0, 0, (meshLength / (_RopeBoneCount - 1)) * i);
            }
        }

        public void SetBonePosition(int index, Vector3 position)
        {
            if (_RopeBones == null) return;
            if (index < 0 || index >= _RopeBones.Length) return;

            _RopeBones[index].position = position;
        }

        public void UpdateBoneRotations()
        {
            for (int i = 0; i < _RopeBoneCount - 1; i++)
            {
                _RopeBones[i].LookAt(_RopeBones[i + 1]);
                //_RopeBones[i].Rotate(Vector3.up, -90);
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(0.0f, 0.0f, 1.0f, 0.6f);

            for (int pointIdx = 0; pointIdx < _Segments + 1; pointIdx++)
            {
                SetBonePosition(pointIdx, _Points[pointIdx].Position);
                Gizmos.DrawSphere(_Points[pointIdx].Position, 0.05f);
            }
        }
        #endregion
    }
}

