using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class Sail : MonoBehaviour
    {
        [Header("Controll Settings")]
        [Range(0, 1)]
        public float rolling = 0;
        [Range(0, 1)]
        public float sailFully = 0;
        [Range(0, 1)]
        public float sailFullyValue = 1;
        [Range(0, 1)]
        public float sailTightlyValue = 0.3f;

        [Header("Rig Settings")]
        public Transform leftAnchor;
        public Transform rightAnchor;

        public Transform leftDynamicPulley;
        public Transform rightDynamicPulley;

        public Transform leftAnchorRollUp;
        public Transform rightAnchorRollUp;

        public Transform leftAnchorOpen;
        public Transform rightAnchorOpen;
        public Mast mast { set; get; }


        [Header("Ropes Settings")]
        //right side
        public Rope R1;
        public Rope R2;
        public Rope R3;

        //left side
        public Rope L1;
        public Rope L2;
        public Rope L3;

        [Range(0, 1)]
        public float dynamicPulleyStartValue = 0.5f;
        [Range(0, 1)]
        public float dynamicPulleyEndValue = 0.7f;

        [Header("Sail Renderer")]
        [SerializeField] SkinnedMeshRenderer sailRenderer;
        int rollIndex;
        int windIndex;

        // Start is called before the first frame update
        void Start()
        {
            if (sailRenderer != null)
            {
                rollIndex = sailRenderer.sharedMesh.GetBlendShapeIndex("Roll");
                windIndex = sailRenderer.sharedMesh.GetBlendShapeIndex("Wind");

                Debug.Log("roll index, wind index :" + rollIndex.ToString() + "," + windIndex.ToString());
            }
        }

        private void OnValidate()
        {
            if (R1 == null || R2 == null || R3 == null ||
                L1 == null || L2 == null || L3 == null)
            {
                Debug.Log("Please set up the complete set of six ropes.");
            }
        }

        // Update is called once per frame
        void Update()
        {
            SetRolling(rolling);
            SetSailFully(sailFully);
        }

        public void SetRolling(float rolling)
        {
            this.rolling = Mathf.Clamp01(rolling);

            if (sailRenderer != null)
            {
                sailRenderer.SetBlendShapeWeight(rollIndex, rolling * 100);
            }

            if (leftAnchor != null)
            {
                if (leftAnchorOpen != null && leftAnchorRollUp != null)
                {
                    leftAnchor.position = Vector3.Lerp(leftAnchorOpen.position, leftAnchorRollUp.position, rolling);
                }

                if (L2 != null)
                {
                    L2.EndPoint.position = leftAnchor.position;
                }

                if (L3 != null)
                {
                    L3.StartPoint.position = leftAnchor.position;
                }
            }

            

            if (rightAnchor != null) 
            {
                if (rightAnchorOpen != null && rightAnchorRollUp != null)
                {
                    rightAnchor.position = Vector3.Lerp(rightAnchorOpen.position, rightAnchorRollUp.position, rolling);
                }
                
                if (R2 != null)
                {
                    R2.EndPoint.position = rightAnchor.position;
                }

                if (R3 != null)
                {
                    R3.StartPoint.position = rightAnchor.position;
                }
            }

            //Dynamic Pulley
            if (L3 != null && L1 != null)
            {
                L3.EndPoint.position = L1.GetRopePosition(Mathf.Lerp(dynamicPulleyStartValue, dynamicPulleyEndValue, rolling));

                if (leftDynamicPulley != null)
                {
                    leftDynamicPulley.position = L3.EndPoint.position;
                }
            }

            if (R3 != null && R1 != null)
            {
                R3.EndPoint.position = R1.GetRopePosition(Mathf.Lerp(dynamicPulleyStartValue, dynamicPulleyEndValue, rolling));

                if (rightDynamicPulley != null)
                {
                    rightDynamicPulley.position = R3.EndPoint.position;
                }
            }
        }

        public void SetSailFully(float sailFully)
        {
            if (sailRenderer != null)
            {
                sailRenderer.SetBlendShapeWeight(windIndex, Mathf.Lerp(sailTightlyValue, sailFullyValue, sailFully) * 100);
            }
        }

        public Vector3 GetDirection()
        {
            if (mast != null)
            {
                return mast.transform.forward;
            }

            return Vector3.forward;
        }
    }
}
