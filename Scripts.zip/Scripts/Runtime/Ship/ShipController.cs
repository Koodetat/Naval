using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class ShipController : MonoBehaviour
    {
        [HideInInspector]
        public ShipDynamics ship;
        [HideInInspector]
        public CannonGroup cannonGroup;

        private void Awake()
        {
            ship = GetComponent<ShipDynamics>();
            cannonGroup = GetComponentInChildren<CannonGroup>();
        }

        public void SetShipImpetus(float vertical, float horizontal)
        {
            if (ship)
            {
                ship.SetImpetus(vertical, horizontal);
            }
        }

        public bool CheckFireFaceGameObject(ShipSide side, GameObject target)
        {
            if (cannonGroup != null) return cannonGroup.CheckFireFaceGameObject(side, target);

            return false;
        }

        public void FireGroup(ShipSide side)
        {
            if (cannonGroup != null) cannonGroup.FireGroup(side);
        }

        public bool HasCannonGroup()
        {
            if (cannonGroup != null) return true;

            return false;
        }

        public void TryShowTrajectory(ShipSide side, bool isVisible)
        {
            if (cannonGroup != null) cannonGroup.TryShowTrajectory(side, isVisible);
        }

        public bool GetShowTrajectory(ShipSide side)
        {
            if (cannonGroup != null)  return cannonGroup.GetShowTrajectory(side);
            return false;
        }

        public void UpdateAim(ShipSide side, float delta)
        {
            if (cannonGroup != null) cannonGroup.UpdateAim(side, delta);
        }

        public Vector3 SetAim(ShipSide side, float angle)
        {
            if (cannonGroup != null) return cannonGroup.SetAim(side, angle);

            return Vector3.forward;
        }
    }
}