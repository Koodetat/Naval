using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public enum ShipOwner
    {
        SO_Player,
        SO_Enemy,
        SO_Monster,
    }

    public class ShipProperties : MonoBehaviour
    {
        public ShipOwner shipOwner;
        public int healthMax = 100;
        public int health = 100;
        public float aiPrepareFireRadius = 300;
        public float aiFireRadius = 200;

        public bool IsDead()
        {
            return health <= 0;
        }
    }
}
