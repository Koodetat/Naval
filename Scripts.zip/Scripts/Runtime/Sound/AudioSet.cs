﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{ 
    public class AudioSet : MonoBehaviour
    {
        public AudioClip[] SoundsList;

        public AudioClip GetRandomSound()
        {
            return SoundsList[Random.Range(0, SoundsList.Length)];
        }
    }
}