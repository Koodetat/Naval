using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class SoundEffect : MonoBehaviour
    {
        private AudioSet audioSet;
        private AudioSource audioSource;

        private void OnEnable()
        {
            audioSource = GetComponent<AudioSource>();
            audioSet = GetComponent<AudioSet>();
            if (audioSource != null && audioSet != null) 
            {
                audioSource.clip = audioSet.GetRandomSound();
                audioSource.Play();
            }
        }
    }
}
