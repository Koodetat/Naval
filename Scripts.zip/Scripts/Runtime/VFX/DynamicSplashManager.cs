using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class DynamicSplashManager : SingletonMono<DynamicSplashManager>
    {
        public ParticleEffect bigExplosionSplash;
        // Start is called before the first frame update
        void Start()
        {
        
        }

        // Update is called once per frame
        void Update()
        {
        
        }

        public void MakeBigSplash(Vector3 position)
        {
            ParticleEffect splash = bigExplosionSplash.Spawn(position, Quaternion.identity);
            splash.needAutoRecycle = true;
            splash.maxDuration = 10;
        }
    }
}
