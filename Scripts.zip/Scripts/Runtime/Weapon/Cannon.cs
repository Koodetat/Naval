using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NavalBattleKit
{
    public class Cannon : MonoBehaviour
    {
        [Header("Cannonball")]
        public float coolDownTime = 4f;
        public float cannonPower = 100f;
        [SerializeField]
        private Cannonball cannonball;
        [SerializeField]
        private CannonGroup cannonGroup;
        private float fireDelay = 0;

        [Header("Trajectory")]
        public Transform cannonMuzzle;
        public LineRenderer trajectory;
        //[Range(0, 70)]
        //public float horizontalAngleRange = 45;
        [Range(-30, 0)]
        public float angleRangeUp = -20;
        [Range(0, 5)]
        public float angleRangeDown = 5;
        public float trajectoryTime = 10;
        [Range(1, 10)]
        public int trajectoryResDiv = 4;

        [SerializeField]
        private AudioSource audioSource;

        [SerializeField]
        private AudioSet audioSet;

        [SerializeField]
        private ParticleEffect fireEffect;

        public bool IsReadyToFire { get => isReadyToFire; set => isReadyToFire = value; }

        bool showTrajectory = false;
        bool isReadyToFire = true;
        //cool down count
        float coolDownCount;

        private void Start()
        {
            Init();

            if (cannonGroup)
            {
                fireDelay = cannonGroup.GetGroupIndex(this) * 0.2f;
            }
        }

        private void Init()
        {
            ToggleTrajectory(false);
            isReadyToFire = true;
            coolDownCount = coolDownTime;
        }

        private void Update()
        {
            //UpdateFire();
            UpdateRefresh(Time.deltaTime);

            if (showTrajectory)
            {
                //UpdateAim(Input.GetAxis("Mouse Y") * Time.deltaTime);
                DrawTrajectory();
            }
        }

        Cannonball SpawnCannonball()
        {
            Cannonball ball = null;

            if (cannonball != null)
            {
                //ball = Instantiate(cannonball, cannonMuzzle.position, Quaternion.identity) as Cannonball;
                ball = cannonball.Spawn(cannonMuzzle.position, Quaternion.identity);
                ball.InitialSpeed = cannonPower;
            }

            return ball;
        }

        public void FireCanon()
        {
            if (isReadyToFire)
            {
                isReadyToFire = false;

                StartCoroutine(DelayedFire());

                if (showTrajectory)
                {
                    ToggleTrajectory(false);
                }
            }
        }

        IEnumerator DelayedFire()
        {
            yield return new WaitForSeconds(fireDelay);

            Cannonball ball = SpawnCannonball();

            if (ball != null)
            {
                ball.FireCannon(Mathf.Deg2Rad * transform.eulerAngles.y, Mathf.Deg2Rad * transform.eulerAngles.x);
            }

            audioSource.clip = audioSet.GetRandomSound();
            audioSource.Play();

            if (fireEffect != null)
            {
                fireEffect.Play();
            }
        }

        Vector3 ComputeInitialVelocity()
        {
            float sinTheta = Mathf.Sin(Mathf.Deg2Rad * transform.eulerAngles.y);
            float cosTheta = Mathf.Cos(Mathf.Deg2Rad * transform.eulerAngles.y);
            float sinPhi = Mathf.Sin(Mathf.Deg2Rad * transform.eulerAngles.x);
            float cosPhi = Mathf.Cos(Mathf.Deg2Rad * transform.eulerAngles.x);

            return cannonPower * new Vector3(cosPhi * sinTheta, -sinPhi, cosPhi * cosTheta);
        }

        private void UpdateRefresh(float delta)
        {
            if (!isReadyToFire)
            {
                coolDownCount -= delta;
            }

            if (coolDownCount <= 0)
            {
                isReadyToFire = true;
                coolDownCount = coolDownTime;
                //ToggleTrajectory(true);
            }
        }

        //-------------------------------input---------------------------
        void UpdateFire()
        {
            //if (Input.GetMouseButtonDown(0))
            //{
            //    FireCanon();
            //}

            //if (Input.GetMouseButtonUp(1))
            //{
            //    ToggleTrajectory(false);
            //}

            //if (!showTrajectory && IsReadyToFire)
            //{
            //    if (Input.GetMouseButtonDown(1))
            //    {
            //        ToggleTrajectory(true);
            //    }
            //}
        }

        public void UpdateAim(float delta)
        {
            float deltaRot = delta * GlobalSetting.animMouseSensitivity;

            float angle = transform.localEulerAngles.x;
            if (angle >= 180) angle = angle - 360;
            angle -= deltaRot;
            angle = Mathf.Clamp(angle, angleRangeUp, angleRangeDown);
            if (angle < 0) angle = angle + 360;
            Vector3 oldAngle = transform.localEulerAngles;
            transform.localEulerAngles = new Vector3(angle, oldAngle.y, oldAngle.z);
        }

        public Vector3 SetAim(float iAngle)
        {
            float angle = iAngle;
            angle = Mathf.Clamp(angle, angleRangeUp, angleRangeDown);
            if (angle < 0) angle = angle + 360;
            Vector3 oldAngle = transform.localEulerAngles;
            transform.localEulerAngles = new Vector3(angle, oldAngle.y, oldAngle.z);
            return transform.forward;
        }
        //---------------------------------------------------------------

        #region Trajectory

        void DrawTrajectory()
        {
            Vector3 gravity = GlobalSetting.gravity;

            float dt = Time.fixedDeltaTime * trajectoryResDiv;
            Vector3 startVelocity = ComputeInitialVelocity();
            Vector3 startPosition = cannonMuzzle.position;

            trajectory.positionCount = Mathf.CeilToInt(trajectoryTime / dt) + 2;

            float time = 0;
            for (int i = 0; i < trajectory.positionCount; i++)
            {
                time = i * dt;
                Vector3 point = startPosition + time * startVelocity;
                point.y = startPosition.y + startVelocity.y * time + (Physics.gravity.y / 2f * time * time);

                trajectory.SetPosition(i, point);

                //Vector3 lastPosition = LineRenderer.GetPosition(i - 1);

                //if (Physics.Raycast(lastPosition,
                //    (point - lastPosition).normalized,
                //    out RaycastHit hit,
                //    (point - lastPosition).magnitude,
                //    GrenadeCollisionMask))
                //{
                //    LineRenderer.SetPosition(i, hit.point);
                //    LineRenderer.positionCount = i + 1;
                //    return;
                //}
            }
        }

        public bool GetShowTrajectory()
        {
            return showTrajectory;
        }

        public void ToggleTrajectory(bool isVisible)
        {
            trajectory.enabled = isVisible;
            showTrajectory = isVisible;
        }

        public bool IsTrajectoryActive()
        {
            return showTrajectory;
        }

        public void TryShowTrajectory(bool isVisible)
        {
            if (isVisible) 
            {
                if (!showTrajectory && IsReadyToFire)
                {
                    ToggleTrajectory(true);
                }
            }
            else
            {
                ToggleTrajectory(false);
            }
        }

        #endregion
    }
}