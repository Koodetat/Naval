using System.Collections;
using System.Linq;
using UnityEngine;

namespace NavalBattleKit
{
    public enum ShipSide
    {
        None,
        Right,
        Left,
        All,
    }

    public class CannonGroup : MonoBehaviour
    {
        [SerializeField] private GameObject rightSideObject;
        [SerializeField] private GameObject leftSideObject;
        private Cannon[] rightSide;
        private Cannon[] leftSide;
        //private Cannon[] allCanons;

        void Awake()
        {
            rightSide = rightSideObject.GetComponentsInChildren<Cannon>();
            leftSide = leftSideObject.GetComponentsInChildren<Cannon>();
            //allCanons = new Cannon[rightSide.Length + leftSide.Length];
            //rightSide.CopyTo(allCanons, 0);
            //leftSide.CopyTo(allCanons, rightSide.Length);
        }

        public int GetGroupIndex(Cannon c)
        {
            for (int i = 0; i < rightSide.Length; i++)
            {
                if (c == rightSide[i]) return i;
            }

            for (int i = 0; i < leftSide.Length; i++)
            {
                if (c == leftSide[i]) return i;
            }

            return 0;
        }

        public Ray GetCannonHorizonLook(ShipSide side, int i)
        {
            Ray r = new Ray();
            Vector3 dir = Vector3.zero;

            if (side == ShipSide.Right)
            {
                r.origin = rightSide[i].transform.position;
                dir = rightSide[i].transform.forward;
                dir.y = 0;
                r.direction = dir.normalized;
            }

            if (side == ShipSide.Left)
            {
                r.origin = leftSide[i].transform.position;
                dir = leftSide[i].transform.forward;
                dir.y = 0;
                r.direction = dir.normalized;
            }

            return r;
        }

        public bool CheckFireFaceGameObject(ShipSide side, GameObject target)
        {
            if (side == ShipSide.Left || side == ShipSide.Right)
            {
                Ray ray = GetCannonHorizonLook(side, 0);
                return CheckRayIntersectGameObject(GetCannonHorizonLook(side, 0), target) ||
                    CheckRayIntersectGameObject(GetCannonHorizonLook(side, 3), target);
            }

            return false;
        }

        bool CheckRayIntersectGameObject(Ray r, GameObject obj)
        {
            RaycastHit hit;
            if (Physics.Raycast(r, out hit, 500))
            {
                GameObject hitObject = hit.collider.gameObject;

                if (hitObject == obj)
                {
                    return true;
                }
            }

            return false;
        }

        public void FireGroup(ShipSide side)
        {
            if (side == ShipSide.None) return;

            if (side == ShipSide.Right || side == ShipSide.All)
            {
                for (int i = 0; i < rightSide.Length; i++)
                {
                    if (rightSide[i] != null) rightSide[i].FireCanon();
                }
            }

            if (side == ShipSide.Left || side == ShipSide.All)
            {
                for (int i = 0; i < leftSide.Length; i++)
                {
                    if (leftSide[i] != null) leftSide[i].FireCanon();
                }
            }
        }

        public void TryShowTrajectory(ShipSide side, bool isVisible)
        {
            if (side == ShipSide.None) return;

            if (side == ShipSide.Right || side == ShipSide.All)
            {
                for (int i = 0; i < rightSide.Length; i++)
                {
                    if (rightSide[i] != null) rightSide[i].TryShowTrajectory(isVisible);
                }
            }

            if (side == ShipSide.Left || side == ShipSide.All)
            {
                for (int i = 0; i < leftSide.Length; i++)
                {
                    if (leftSide[i] != null) leftSide[i].TryShowTrajectory(isVisible);
                }
            }
                
        }

        public bool GetShowTrajectory(ShipSide side)
        {
            if (side == ShipSide.None) return false;

            bool show = false;
            if (side == ShipSide.Right || side == ShipSide.All)
            {
                if (rightSide.Length > 0 && rightSide[0].GetShowTrajectory())
                {
                    show = true;
                }
            }

            if (side == ShipSide.Left || side == ShipSide.All)
            {
                if (leftSide.Length > 0 && leftSide[0].GetShowTrajectory())
                {
                    show = true;
                }
            }
                
            return show;
        }

        public void UpdateAim(ShipSide side, float delta)
        {
            if (side == ShipSide.None) return;

            if (side == ShipSide.Right || side == ShipSide.All)
            {
                for (int i = 0; i < rightSide.Length; i++)
                {
                    if (rightSide[i] != null) rightSide[i].UpdateAim(delta);
                }
            }

            if (side == ShipSide.Left || side == ShipSide.All)
            {
                for (int i = 0; i < leftSide.Length; i++)
                {
                    if (leftSide[i] != null) leftSide[i].UpdateAim(delta);
                }
            }
        }

        public Vector3 SetAim(ShipSide side, float angle)
        {
            Vector3 dir = Vector3.zero;

            if (side == ShipSide.None || side == ShipSide.All) return dir;

            if (side == ShipSide.Right)
            {
                for (int i = 0; i < rightSide.Length; i++)
                {
                    if (rightSide[i] != null) dir = rightSide[i].SetAim(angle);
                }
            }

            if (side == ShipSide.Left)
            {
                for (int i = 0; i < leftSide.Length; i++)
                {
                    if (leftSide[i] != null) dir = leftSide[i].SetAim(angle);
                }
            }
            
            return dir;
        }
    }
}

