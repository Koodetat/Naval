﻿using System.Collections;
using UnityEngine;
using UniversalWaterSystem;

namespace NavalBattleKit
{
    public class Cannonball : MonoBehaviour
    {
        private Vector3 velocity;

        private float horizontalAngle;
        private float elevationAngle;
        private float initialSpeed;

        [HideInInspector] public float InitialSpeed { get => initialSpeed; set => initialSpeed = value; }

        //private bool cannonLaunched;

        public float maxDuration = 10;
        float durationCounter;

        [SerializeField] private Rigidbody physicsBody;
        [SerializeField] private AudioSource audioSource;
        //[SerializeField] private SoundController soundController;
        [SerializeField] private ParticleEffect explosionPrefab;
        //[SerializeField] private MeshRenderer meshRenderer;

        private void OnEnable()
        {
            ResetCannonball();

            StartCoroutine(DelayedRecycle());
        }

        IEnumerator DelayedRecycle()
        {
            yield return new WaitForSeconds(maxDuration);

            gameObject.Recycle();
        }

        //private void Update()
        //{
        //    durationCounter -= Time.deltaTime;
        //    if (durationCounter <= 0)
        //    {
        //        gameObject.Recycle();
        //    }
        //}

        Vector3 ComputeInitialVelocity()
        {
            float sinTheta = Mathf.Sin(horizontalAngle);
            float cosTheta = Mathf.Cos(horizontalAngle);
            float sinPhi = Mathf.Sin(elevationAngle);
            float cosPhi = Mathf.Cos(elevationAngle);

            return initialSpeed * new Vector3(cosPhi * sinTheta, -sinPhi, cosPhi * cosTheta);
        }

        public void FireCannon(float hAngle, float eAngle)
        {
            InitializeCannonball();
            horizontalAngle = hAngle;
            elevationAngle = eAngle;

            velocity = ComputeInitialVelocity();
            //cannonLaunched = true;

            if (physicsBody != null)
            {
                physicsBody.linearVelocity = velocity;
            }
        }

        void InitializeCannonball()
        {
            //explosionEffect?.Stop();
            //meshRenderer.enabled = true;
        }

        public void ResetCannonball()
        {
            durationCounter = maxDuration;
            //cannonLaunched = false;
            //explosionEffect?.Stop();
            //meshRenderer.enabled = true;
            if (physicsBody != null)
            {
                physicsBody.linearVelocity = Vector3.zero;
            }
        }

        void OnCollisionEnter(Collision collision)
        {
            foreach (ContactPoint contact in collision.contacts)
            {
                if (contact.otherCollider.CompareTag("Ship"))
                {
                    HandleShipCollision(contact.point, contact.otherCollider.gameObject.GetComponentInParent<ShipProperties>());
                }
            }
        }

        private void FixedUpdate()
        {
            float waterHeight = Water.Instance.GetWaterHeight(transform.position);

            if (waterHeight > transform.position.y)
                HandleWaterCollision(transform.position);
        }

        void HandleShipCollision(Vector3 position, ShipProperties ship)
        {
            SpawnExplosionFX(position);

            velocity = Vector3.zero;
            if (physicsBody != null)
            {
                physicsBody.linearVelocity = Vector3.zero;
            }

            gameObject.Recycle();

            EventBetter.Raise(new CannonballHitShipMessage() { ball = this, ship = ship });
        }

        ParticleEffect SpawnExplosionFX(Vector3 position)
        {
            ParticleEffect pe = explosionPrefab.Spawn(position, Quaternion.identity);
            return pe;
        }

        void HandleWaterCollision(Vector3 position)
        {
            DynamicSplashManager.Instance.MakeBigSplash(position);

            velocity = Vector3.zero;
            if (physicsBody != null)
            {
                physicsBody.linearVelocity = Vector3.zero;
            }

            gameObject.Recycle();
        }
    }
}